Nicolae Cleju
Technical University Gheorghe Asachi of Iasi, Romania
Queen Mary, University of London
24.02.2012

Python Compressed Sensing algorithms
-------------------------------------

Python implementation of various Compressed Sensing algorithms originally implemented in Matlab.


How to install
---------------
Run 'python setup.py install'